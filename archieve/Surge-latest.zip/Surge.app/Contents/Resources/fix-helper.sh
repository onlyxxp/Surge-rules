#!/bin/bash

#  fix-helper.sh
#  Surge
#
#  Created by Blankwonder on 2021/8/14.
#  Copyright © 2021 Yach. All rights reserved.

sudo /bin/launchctl load -w /Library/LaunchDaemons/com.nssurge.surge-mac.helper.plist
